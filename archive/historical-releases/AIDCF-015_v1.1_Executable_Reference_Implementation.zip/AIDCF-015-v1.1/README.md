# AIDCF-015 v1.1 Executable Reference Implementation
Synthetic, non-production package with schemas, registries, JSON-LD, Turtle ontology, SHACL shapes, validation outputs, graph-query results, and score re-performance.

Run: `python tools/run_all.py`

SHACL shapes are included. An RDF/SHACL runtime was unavailable in the isolated build environment, so SHACL execution remains an independent release gate. JSON Schema and AIDCF business-rule validation were executed.
