# v1.1
- Added actual schemas, registries, synthetic JSON-LD data, ontology and SHACL shapes.
- Added captured JSON/business validation, graph-query results and score re-performance evidence.
- Normalized gate results to the controlled vocabulary; conditions are separate.
- Preserved the AIDCF-007 baseline conflict and non-canonical local pilot controls.
