from pathlib import Path
import json
R=Path(__file__).resolve().parents[1]
for p in ['outputs/validation-results.json','outputs/graph-query-results.json','outputs/score-reperformance.json']:
 print(p,json.loads((R/p).read_text()))
